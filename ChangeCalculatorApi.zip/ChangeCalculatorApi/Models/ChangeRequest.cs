namespace ChangeCalculatorApi.Models
{
    public class ChangeRequest
    {
        public decimal Amount { get; set; }
    }
}
